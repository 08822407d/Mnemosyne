# MNEMOSYNE-239 — One-shot local-Git Phase A and originating-connector Phase B

```yaml
task_id: MNEMOSYNE-239
base: e726dea818dca9418181775d0e7dcd62eb6c464a
new_branch: mnemosyne-239-f2-g2a-and-handoff-audit-closeout
historical_branch_untouched: mnemosyne-235-f2-g2a-and-handoff-audit-closeout
external_manifest_id: MNEMOSYNE-239-OPERATOR-PAYLOAD-MANIFEST-001
changed_path_count: 86
retry: false
cleanup: false
merge: false
G2A: false
A1: false
```

Read the external JSON manifest as the only path/byte authority. Phase A must use the supplied executor exactly once on a local, networked, authenticated Git surface. Before launch, GitHub connector must confirm master/base, old branch/base, new branch absence, zero related open PRs, validation master and A1-branch absence. Do not interrupt Phase A with new branch/path/authority instructions.

Phase A success is `MNEMOSYNE_239_BRANCH_PUSHED_PENDING_READY_PR`, not full completion. Return the exact receipt to the originating Pro conversation. That conversation performs Phase B readback and opens one Ready PR with the supplied body. Do not use `gh`, object API or Contents API for Phase A; do not retry 235–239, reuse/clean objects, write validation, issue G2A/A1, amend, force-push, create a second commit or merge.
