# MNEMOSYNE-240 Durable Staging Capsule

This capsule is an emergency preservation artifact. It is not an execution package and does not authorize a repository publication, PR, G2A, A1, cleanup or retry.

It contains the exact repository payload ZIP, external payload manifest, embedded task and PR body, and the superseding Ubuntu operator revision. Keep the outer capsule intact. If local automation remains unavailable, it may be manually uploaded as one binary file to a dedicated preservation branch for durable storage; expansion/publication remains a later separately authorized task.
