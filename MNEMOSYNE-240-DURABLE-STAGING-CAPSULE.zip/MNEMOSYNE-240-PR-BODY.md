## Summary

Publishes the complete F2 corrected-G2A, handoff-audit, HVAL-design and publication-incident closeout as one exact commit under `MNEMOSYNE-240`.

This is the Ubuntu-native additive successor to permanently blocked tasks 235–239. It records rather than retries them. The historical empty 235 branch remains untouched.

## Publication shape

- Base: `master@e726dea818dca9418181775d0e7dcd62eb6c464a`
- Head: `mnemosyne-240-f2-g2a-and-handoff-audit-closeout`
- Historical branch retained: `mnemosyne-235-f2-g2a-and-handoff-audit-closeout@e726dea818dca9418181775d0e7dcd62eb6c464a`
- One commit, **91 exact changed paths** (87 add + 4 modify)
- Phase A: native Ubuntu local Git, one non-force push, exact post-push readback
- Phase B: originating Pro connector exact readback and this Ready PR
- No merge by the task

## Formal dispositions

- Packages 004→003→002→001 readiness: PASS back to Owner gate
- Fable composite G2A candidate: preserved but not directly issuable
- Pro-corrected two-layer G2A template: published for later exact path/blob readback
- `G2A_issued: false`; `A1_execution_authorized: false`; no Package 005
- Handoff repository audit: accepted with Pro corrections
- HVAL Design 002: accepted for **separate** Owner authorization; no fixture publication/execution here
- 235–239: blocked, closed, no retry; incident evidence published

## 239 incident and 240 repair

239 passed its exact payload/base checks but Windows rejected a valid long manifest path during `git add`; no commit, push, remote branch or PR was created. 240 does not retry 239. It uses native Ubuntu 24.04, an automated preflight, an automatically created short execution root, a new task-aligned branch, and the same deterministic local-Git publication geometry.

## Explicit exclusions

No `commands/`, active guard or `current/human-approved-spec.md` change; no validation-repository, Meta-Agent or real-target write; no G2A/A1; no HVAL fixture publication/execution; no retry, cleanup, amend, force-push, second commit or merge.

## Recommendation and next gate

**`RECOMMEND_MERGE`** after reviewing the exact diff and receipts. After merge: exact corrected-template/manifest/validator/status readback → authorized dynamic fill → mechanical validator → separate explicit Owner decision whether to issue A1 controller G2A. Merge alone authorizes neither G2A nor A1.
