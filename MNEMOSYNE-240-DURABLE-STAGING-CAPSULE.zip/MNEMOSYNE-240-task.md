# MNEMOSYNE-240 — Ubuntu-native one-package Phase A and originating-connector Phase B

```yaml
task_id: MNEMOSYNE-240
base: e726dea818dca9418181775d0e7dcd62eb6c464a
new_branch: mnemosyne-240-f2-g2a-and-handoff-audit-closeout
historical_branch_untouched: mnemosyne-235-f2-g2a-and-handoff-audit-closeout
failed_239_branch_expected_absent: mnemosyne-239-f2-g2a-and-handoff-audit-closeout
external_manifest_id: MNEMOSYNE-240-OPERATOR-PAYLOAD-MANIFEST-001
changed_path_count: 91
preflight_before_formal_start: true
retry: false
cleanup: false
merge: false
G2A: false
A1: false
```

The sole operator artifact is `MNEMOSYNE-240-UBUNTU-OPERATOR.pyz`. The agent must verify the published zipapp SHA-256, print/read this embedded task, and run the zipapp with `--auto` from native Ubuntu 24.04. The launcher automatically creates all directories, performs the non-mutating preflight, and starts the one-shot executor only after readiness passes.

No manual shell or folder creation is required from the Owner. Do not unpack or modify embedded resources. Do not interrupt formal execution with new branch/path/authority instructions.

Phase A success is `MNEMOSYNE_240_BRANCH_PUSHED_PENDING_READY_PR`. Return the exact execution receipt to the originating Pro conversation. That conversation performs Phase B readback and opens one Ready PR with the embedded body. Do not use `gh`, the low-level object API or Contents API; do not retry 235–240, reuse/clean objects or historical branches, write validation, publish/execute HVAL fixtures, issue G2A/A1, amend, force-push, create a second commit or merge.
