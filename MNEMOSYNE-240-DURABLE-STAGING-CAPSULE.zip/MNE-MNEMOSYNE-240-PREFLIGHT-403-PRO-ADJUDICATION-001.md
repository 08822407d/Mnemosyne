# MNEMOSYNE-240 Surface Preflight 403 — Pro Adjudication 001

```yaml
adjudication_id: MNE-MNEMOSYNE-240-PREFLIGHT-403-PRO-ADJUDICATION-001
source_task: MNEMOSYNE-240
source_operator_package: MNEMOSYNE-240-UBUNTU-OPERATOR.pyz
source_result: SURFACE_NOT_READY_FOR_MNEMOSYNE_240
formal_execution_started: false
repository_write_observed: false
package_revision_authorized: MNEMOSYNE-240-UBUNTU-OPERATOR-REVISION-002
same_task_formal_retry: not_applicable_formal_never_started
```

## Finding

The receipt shows exactly two successful `git ls-remote` commands followed by `HTTPError 403: rate limit exceeded`. Inspection of the frozen launcher shows that immediately after those two commands it called `open_prs()`, which used `urllib.request` against the GitHub REST API. The launcher authenticated that REST request only when `GH_TOKEN` or `GITHUB_TOKEN` was already exported into the local process. The VS Code Codex GitHub integration does not itself guarantee that its credential is exported to the local terminal process.

The earlier response recommending only waiting for the anonymous rate limit to reset was insufficient. The formal executor repeated the same REST pattern before materialization, commit and push. Even if a later preflight passed anonymously, the formal run could have consumed its one-shot lineage on a later 403.

## Disposition

The formal task was not consumed because `formal_execution_started` was false and no formal-start marker, worktree, commit, branch, push or PR was created. The original repository payload, manifest, verifier, executor and PR body remain byte-identical. Only the outer Ubuntu launcher is superseded.

Revision 002 obtains an authenticated API token without exposing or persisting it, in this order:

1. existing `GH_TOKEN`;
2. existing `GITHUB_TOKEN`;
3. `gh auth token`, when available;
4. `git credential fill` for `https://github.com`.

It verifies authenticated core rate-limit headroom, uses the token for the preflight REST calls, and injects the token only into the formal executor process so the executor's repeated PR checks are authenticated. The token is not written to receipts or logs.

```yaml
old_operator_package: SUPERSEDED_DO_NOT_RUN
new_operator_package: MNEMOSYNE-240-UBUNTU-OPERATOR-REVISION-002.pyz
new_operator_sha256: 028a47167d79ae39a5546b79c4969e7de86a2d1497d5f88a2f503430d5756ff1
formal_payload_changed: false
formal_task_id_changed: false
G2A_issued: false
A1_execution_authorized: false
```
