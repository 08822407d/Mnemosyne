
# Mnemosyne AI Start Here

> Non-execution-source navigation for repository reviewers and agents. `current/human-approved-spec.md` is the only Mnemosyne execution source.

## What Mnemosyne is

Mnemosyne is a design and delivery repository for external persistent-memory systems used by AI agents and projects. Models perform computation; versioned files provide durable memory and auditability.

## Before doing anything

1. Identify the requested mode: analysis/advice, formal review, local maintenance, or takeover.
2. Read `current/human-approved-spec.md`.
3. For behavior-guidance refresh, read `commands/load-mnemosyne-guidance.md` and the files it selects.
4. Read the task-specific package or direct Owner instruction.
5. Reverify current repository, branch and PR state when the task depends on it.
6. Do not infer a live task from status, TODO, active-context or handoff files.

## Minimal reading profiles

### Analysis or advice

- this file;
- `current/human-approved-spec.md`;
- `MNEMOSYNE-REPOSITORY-MAP.yaml`;
- exact files named by the user's question.

Default: read-only.

### Formal review

Add the exact review package, manifest, status and cited evidence. Distinguish repository facts, source claims, inference and recommendation.

### Local maintenance

Add `commands/load-mnemosyne-guidance.md`, relevant guards, current branch/PR state and the explicit write task. Ordinary local engineering choices are allowed; authority and final invariants remain fixed.

### Takeover

Takeover requires an explicit Owner-selected task or handoff. Load guidance, reconstruct the task, state authority/exclusions, and confirm the continuation gate before substantive work.

## Authority summary

```text
current/human-approved-spec.md
        ↓
approved behavior/process guards for their stated scope
        ↓
explicit current task / Owner instruction
        ↓
status, handoff, TODO, research and raw evidence as non-execution-source inputs
```

When sources conflict, preserve the conflict and follow the execution source.

## Evidence discipline

- Do not load cold originals by default.
- Verify time-sensitive platform, model and repository facts.
- Never treat a recommendation as an Owner decision.
- Never treat merge as proof of line-by-line human review.
- Check repository visibility before adding material.
