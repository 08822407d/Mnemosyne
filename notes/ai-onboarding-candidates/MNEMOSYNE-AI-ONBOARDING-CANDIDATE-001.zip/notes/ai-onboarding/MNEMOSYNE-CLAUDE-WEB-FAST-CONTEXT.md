
# Claude Web / Fable 5 Fast Context for Mnemosyne

Use this as a compact entry card, not as task authority.

Mnemosyne is a repository for designing, auditing and delivering persistent external-memory systems for AI agents. Its only execution source is `current/human-approved-spec.md`.

For a read-only analysis:

1. read the execution source;
2. read `notes/ai-onboarding/MNEMOSYNE-REPOSITORY-MAP.yaml`;
3. read only the exact status/design/evidence files named by the question;
4. keep cold `raw/` originals on-demand;
5. label repository facts, source claims, inference and recommendations separately;
6. verify current platform/model/repository facts when material;
7. do not infer a handoff, write task or Owner decision.

For a formal review, require a frozen review package and manifest.

For a takeover, require a separate exact task/handoff and guidance refresh. This card cannot authorize continuation or repository writes.
