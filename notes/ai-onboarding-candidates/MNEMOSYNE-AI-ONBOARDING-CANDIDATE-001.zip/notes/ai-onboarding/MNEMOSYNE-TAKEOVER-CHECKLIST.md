
# Mnemosyne Takeover Checklist

- [ ] Owner explicitly selected takeover or continuation.
- [ ] Exact task or handoff package identified.
- [ ] Repository and execution-time branch state verified.
- [ ] `current/human-approved-spec.md` read.
- [ ] Required guidance loaded without replacing the transferred task.
- [ ] Local task restated.
- [ ] Authority and prohibited actions restated.
- [ ] Required evidence paths and preservation levels identified.
- [ ] Dynamic facts reverified.
- [ ] Open questions separated from approved work.
- [ ] Write authority, target repository and PR lineage confirmed.
- [ ] Current Agent states whether it is ready, blocked, or awaiting Owner decision.

Without an exact selected task, remain in read-only analysis/advice mode.
