
# Mnemosyne Authority and Evidence

## Execution authority

`current/human-approved-spec.md` is the only execution source.

Behavior guards and commands constrain work only within their stated scope. A task-specific package or direct Owner message supplies the local task, but may not override the execution source without an approved repository change.

## Non-execution-source material

The following may be important evidence but do not independently authorize work:

- README and navigation files;
- current status and active-context files;
- handoff packages;
- TODOs and open questions;
- research reports;
- validation reviews;
- decision records;
- raw originals;
- model memory or prior chat context.

## Claim labels

Use these labels where ambiguity matters:

```text
VERIFIED_REPOSITORY_FACT
SOURCE_ARTIFACT_CLAIM
OWNER_REPORTED_FACT
MODEL_INFERENCE
DESIGN_RECOMMENDATION
UNKNOWN_REQUIRES_EVIDENCE
```

## Write boundary

Before writing, identify:

- repository and visibility;
- exact branch and PR lineage;
- authorized changed-path scope;
- material safety;
- source identities;
- validation and rollback expectations.

Analysis, advice, review and takeover preparation do not imply write authority.
