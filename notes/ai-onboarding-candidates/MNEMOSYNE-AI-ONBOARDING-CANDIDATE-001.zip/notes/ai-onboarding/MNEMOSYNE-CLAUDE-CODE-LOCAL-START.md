
# Claude Code Local Start for Mnemosyne

This file is non-execution-source navigation.

## Read order

1. `current/human-approved-spec.md`
2. `commands/load-mnemosyne-guidance.md` when guidance refresh is selected
3. `notes/ai-onboarding/MNEMOSYNE-REPOSITORY-MAP.yaml`
4. the explicit task/work order
5. only the task-relevant status, guards and evidence

## Local engineering behavior

You may use normal professional judgment for:

- repository checkout and temporary worktrees;
- search and inspection;
- scripts and validators;
- test selection;
- staging and commit organization;
- ordinary local error correction.

Before remote writes, verify:

- current `master`;
- branch and open-PR lineage;
- changed-path scope;
- source identities;
- final diff and tests.

Do not write `master` directly, infer authority from navigation files, import unrelated routes, or treat a local tooling failure as permission to change task semantics.

Return final paths, validation, commits, PR state, limitations and next gate.
